import 'package:dio/dio.dart';

class ApiClient {
  final Dio dio;
  String? _accessToken;
  void Function()? onUnauthorized;
  Future<String?> Function()? tokenGetter;

  ApiClient(this.dio);

  static ApiClient create(String baseUrl) {
    final dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 90),
      receiveTimeout: const Duration(seconds: 90),
      sendTimeout: const Duration(seconds: 90),
    ));
    final client = ApiClient(dio);

    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        if (client._accessToken == null && client.tokenGetter != null) {
          try {
            final stored = await client.tokenGetter!();
            if (stored != null && stored.isNotEmpty) {
              client._accessToken = stored;
            }
          } catch (_) {}
        }
        if (client._accessToken != null) {
          options.headers['Authorization'] = 'Bearer ${client._accessToken}';
        }
        return handler.next(options);
      },
      onError: (DioException e, handler) {
        if (e.response?.statusCode == 401) {
          // final path = e.requestOptions.path;
          // if (!path.contains('/auth/login') &&
          //     !path.contains('/auth/signup') &&
          //     !path.contains('/auth/verify')) {
          //   client.onUnauthorized?.call();
          // }
        }
        return handler.next(e);
      },
    ));
    return client;
  }

  void setToken(String token) {
    _accessToken = token;
  }

  void clearToken() {
    _accessToken = null;
  }

  bool get hasToken => _accessToken != null && _accessToken!.isNotEmpty;

  // Token Verification
  Future<Response> verifyToken() async {
    return dio.get('/auth/verify');
  }

  // User Profile
  Future<Response> getMe() async {
    return dio.get('/users/me');
  }

  Future<Response> updateProfile(Map<String, dynamic> payload) async {
    return dio.put('/users/me', data: payload);
  }

  Future<Response> changePassword(String currentPassword, String newPassword) async {
    return dio.put('/users/me/password', data: {
      'current_password': currentPassword,
      'new_password': newPassword,
    });
  }

  Future<Response> deleteMyAccount(String password) async {
    return dio.post('/users/me/delete', data: {
      'password': password
    });
  }

  // Business Profile
  Future<Response> getBusiness() async {
    return dio.get('/business/me');
  }

  Future<Response> updateBusiness(Map<String, dynamic> payload) async {
    return dio.put('/business/me', data: payload);
  }

  // Staff Management
  Future<Response> listStaff() async {
    return dio.get('/staff/');
  }

  Future<Response> createStaff(Map<String, dynamic> payload) async {
    return dio.post('/staff/', data: payload);
  }

  Future<Response> deactivateStaff(int id) async {
    return dio.patch('/staff/$id/deactivate');
  }

  Future<Response> reactivateStaff(int id) async {
    return dio.patch('/staff/$id/reactivate');
  }

  Future<Response> removeStaff(int id) async {
    return dio.delete('/staff/$id');
  }

  // Authentication  // Auth
  static Options? _captchaOptions(String? captchaToken) =>
      captchaToken == null || captchaToken.isEmpty ? null : Options(headers: {'X-Captcha-Token': captchaToken});

  Future<Response> login(String email, String password, {String? captchaToken}) async {
    return dio.post('/auth/login', data: {
      'email': email,
      'password': password
    }, options: _captchaOptions(captchaToken));
  }

  Future<Response> signup({
    required String businessName,
    required String businessRegistrationNumber,
    required String businessContactNumber,
    required String email,
    required String password,
    String? fullName,
    String? phone,
    String? captchaToken,
  }) async {
    return dio.post('/auth/signup', data: {
      'business_name': businessName,
      'business_registration_number': businessRegistrationNumber,
      'business_contact_number': businessContactNumber,
      'email': email,
      'password': password,
      'full_name': fullName ?? '',
      'phone': phone ?? '',
    }, options: _captchaOptions(captchaToken));
  }

  Future<Response> googleLogin(String firebaseToken) async {
    return dio.post('/auth/google', data: {'firebase_token': firebaseToken});
  }

  Future<Response> refreshToken(String refreshToken) async {
    return dio.post('/auth/refresh', data: {'refresh_token': refreshToken});
  }

  // Customers
  Future<Response> listCustomers({Map<String, dynamic>? params}) async {
    return dio.get('/customers/', queryParameters: params);
  }

  Future<Response> createCustomer(Map<String, dynamic> payload) async {
    return dio.post('/customers/', data: payload);
  }

  Future<Response> updateCustomer(int id, Map<String, dynamic> payload) async {
    return dio.put('/customers/$id', data: payload);
  }

  Future<Response> deleteCustomer(int id) async {
    return dio.delete('/customers/$id');
  }

  // Orders
  Future<Response> listOrders({Map<String, dynamic>? params}) async {
    return dio.get('/orders/', queryParameters: params);
  }

  Future<Response> createOrder(Map<String, dynamic> payload) async {
    return dio.post('/orders/', data: payload);
  }

  Future<Response> getOrder(int id) async {
    return dio.get('/orders/$id');
  }

  Future<Response> updateOrder(int id, Map<String, dynamic> payload) async {
    return dio.put('/orders/$id', data: payload);
  }

  Future<Response> deleteOrder(int id) async {
    return dio.delete('/orders/$id');
  }

  Future<Response> getOrderStats() async {
    return dio.get('/orders/stats');
  }

  // Reports & Analytics
  /// Everything for the Reports page. days: 7/30/90/365, 0 = all time.
  Future<Response> getReportsOverview(int days) => dio.get('/reports/overview', queryParameters: {'days': days});

  Future<Response> getDashboard({String? fromDate, String? toDate}) async {
    final params = <String, dynamic>{};
    if (fromDate != null) params['from_date'] = fromDate;
    if (toDate != null) params['to_date'] = toDate;
    return dio.get('/reports/dashboard', queryParameters: params);
  }

  Future<Response> getStaffPerformance({String? fromDate, String? toDate}) async {
    final params = <String, dynamic>{};
    if (fromDate != null) params['from_date'] = fromDate;
    if (toDate != null) params['to_date'] = toDate;
    return dio.get('/reports/staff-performance', queryParameters: params);
  }

  // AI
  Future<Response> estimateFabric(Map<String, dynamic> payload) async {
    return dio.post('/ai/estimate-fabric', data: payload);
  }

  Future<Response> recommendFabric(Map<String, dynamic> payload) async {
    return dio.post('/ai/recommend-fabric', data: payload);
  }

  Future<Response> predictMeasurements(Map<String, dynamic> payload) async {
    return dio.post('/ai/predict-measurements', data: payload);
  }

  Future<Response> predictMeasurementsFoundry(Map<String, dynamic> payload) async {
    return dio.post('/ai/foundry-predict', data: payload);
  }

  Future<Response> getMeasurementInputRanges(String garmentType) async {
    return dio.get('/ai/input-ranges/$garmentType');
  }

  /// Virtual try-on: sends the customer photo + dress description, returns
  /// `{image_base64, mime_type}`. Image generation can take a while.
  Future<Response> virtualTryOn(List<int> imageBytes, String filename, String dressDescription) async {
    final form = FormData.fromMap({
      'dress_description': dressDescription,
      'image': MultipartFile.fromBytes(imageBytes, filename: filename),
    });
    return dio.post(
      '/ai/virtual-tryon',
      data: form,
      options: Options(receiveTimeout: const Duration(seconds: 150), sendTimeout: const Duration(seconds: 60)),
    );
  }

  /// Estimated free try-ons left today.
  Future<Response> getTryOnUsage() async {
    return dio.get('/ai/virtual-tryon/usage');
  }

  // Inventory (owner only)
  Future<Response> listInventory() => dio.get('/inventory/');
  Future<Response> inventoryAlerts() => dio.get('/inventory/alerts');
  Future<Response> createInventoryItem(Map<String, dynamic> payload) => dio.post('/inventory/', data: payload);
  Future<Response> updateInventoryItem(int id, Map<String, dynamic> payload) => dio.put('/inventory/$id', data: payload);
  Future<Response> restockInventoryItem(int id, double meters, {String? note}) =>
      dio.post('/inventory/$id/restock', data: {'meters': meters, if (note != null && note.isNotEmpty) 'note': note});
  Future<Response> inventoryHistory(int id) => dio.get('/inventory/$id/history');
  Future<Response> deleteInventoryItem(int id) => dio.delete('/inventory/$id');
  Future<Response> addSampleFabrics() => dio.post('/inventory/samples');

  // Measurement Templates
  Future<Response> getMeasurementTemplates() async {
    return dio.get('/measurement-templates/');
  }

  Future<Response> getMeasurementTemplateByCategory(String categoryName) async {
    return dio.get('/measurement-templates/$categoryName');
  }

  Future<Response> createMeasurementTemplate(Map<String, dynamic> payload) async {
    return dio.post('/measurement-templates/', data: payload);
  }

  Future<Response> updateMeasurementTemplate(int id, Map<String, dynamic> payload) async {
    return dio.put('/measurement-templates/$id', data: payload);
  }

  Future<Response> deleteMeasurementTemplate(int id) async {
    return dio.delete('/measurement-templates/$id');
  }
}
